# KAR Labs.dev — Static Production Site

Production website KAR Labs.dev menggunakan **static HTML, compiled CSS, dan Vanilla JavaScript**. Build production tidak bergantung pada Vite/React dan tidak lagi menjalankan Tailwind di browser.

## Development

```bash
npm run dev
```

`npm run dev` akan menjalankan compile Tailwind lokal terlebih dahulu, lalu membuka static dev server.

Default local URL:

```text
http://localhost:5173/
http://localhost:5173/catalog.html
```

## Production checks

Sebelum deploy jalankan:

```bash
npm run check
```

Flow `npm run check`:

1. Validasi source, SEO, dependency hardening, dan Tailwind production setup (`scripts/check.cjs`)
2. `npm run build`
   - compile utility Tailwind menjadi `public/tailwind.css`
   - copy static production files ke `dist/`
3. Validasi output `dist/` (`scripts/check-dist.cjs`)

Build manual:

```bash
npm run build
```

Compile CSS saja:

```bash
npm run build:css
```

Output production: `dist/`.

## Production architecture

- `index.html` — landing page utama
- `catalog.html` — katalog/demo interaktif
- `public/tailwind.css` — generated Tailwind production CSS
- `public/index.js` — interaction script homepage yang cacheable
- `public/catalog.css` — custom styling katalog
- `public/catalog-*.js` — module Vanilla JS katalog per fitur
- `styles/tailwind-theme.css` — custom KAR Labs Tailwind design tokens
- `tailwind.config.js` — production content manifest + safelist
- `scripts/build-tailwind.cjs` — local Tailwind compiler step
- `vendor/tailwindcss/` — compiler core yang dipin ke 4.1.10 untuk deterministic build tanpa npm dependency tambahan
- `scripts/build.cjs` — static copy build ke `dist/`
- `scripts/check.cjs` — source integrity checks
- `scripts/check-dist.cjs` — production output checks
- `robots.txt` / `sitemap.xml` — technical SEO
- `netlify.toml` — Netlify build + security/cache headers

Folder `src/`, konfigurasi Vite/TypeScript/PostCSS, dan scaffold terkait masih dipertahankan sebagai legacy reference tetapi **bukan bagian dari production build**. Jangan memindahkan production kembali ke Vite/React tanpa keputusan arsitektur terpisah.

`public/catalog-tailwind-config.js` juga tetap ada di source untuk compatibility saat overwrite patch lama, tetapi **sudah tidak direferensikan dan tidak ikut ke `dist/`** sejak v2.9.0.

## External dependencies

Runtime website sekarang memakai CDN hanya untuk:

- Chart.js **4.5.1 pinned + lazy-loaded** — baru di-download ketika Calculator/Dashboard dibuka
- Lucide Icons **1.47.0 pinned + defer-loaded**
- Google Fonts — satu request gabungan dengan `preconnect` dan `display=swap`

**Tailwind Play CDN sudah dihapus dari runtime sejak v2.9.0.** Tailwind utility CSS di-compile secara lokal menjadi `public/tailwind.css` saat `npm run dev`, `npm run build:css`, atau `npm run build` dijalankan.

Asset lokal di `/public/*` memakai cache browser 1 hari + `stale-while-revalidate` 7 hari. HTML tetap `must-revalidate` agar deploy baru tidak tertahan cache browser.

## Deployment

Production flow:

```text
GitHub main
  -> Netlify
  -> npm run build
  -> build:css (local Tailwind compiler)
  -> static copy
  -> dist/
```

Netlify publish directory: `dist`. Node version: `20`.

Tidak ada `npm install` tambahan untuk Tailwind v2.9.0 karena compiler production yang diperlukan sudah dipin di repo.

## Version notes

### v2.6.0 — Catalog Modularization
`catalog.html` dipisah menjadi CSS dan module JavaScript per fitur tanpa mengubah static build architecture.

### v2.7.0 — Production Hardening & SEO Foundation
Menambahkan source/dist validation, SEO metadata, canonical URLs, robots/sitemap, social preview, pinned Chart.js/Lucide versions, Netlify security headers, modal HTML/accessibility cleanup, dan chatbot DOM escaping.

### v2.8.0 — Frontend Asset Optimization
Memindahkan JavaScript homepage dari inline ke asset cacheable, lazy-load Chart.js hanya pada fitur yang membutuhkan chart, pin Tailwind CDN, defer Lucide, WebP + lazy decoding untuk preview BUDS Motor, serta cache policy Netlify yang aman.

### v2.9.0 — Tailwind Production Build Migration
Menghapus Tailwind Play CDN dari runtime dan menggantinya dengan local deterministic compiler + generated `public/tailwind.css`. Build, dev, source checks, dan dist checks sekarang menjaga agar runtime Tailwind CDN tidak kembali masuk ke production.
